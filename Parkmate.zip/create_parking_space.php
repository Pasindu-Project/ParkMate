<?php
// C:\xampp\htdocs\Parkmate\create_parking_space.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require __DIR__ . '/db.php';

try {
  // -------- Required scalar fields (multipart/form-data) --------
  $owner_id     = isset($_POST['owner_id']) ? (int)$_POST['owner_id'] : 0;
  $parking_name = trim((string)($_POST['parking_name'] ?? ''));
  $location     = trim((string)($_POST['location'] ?? ''));
  $availability = trim((string)($_POST['availability'] ?? ''));
  $description  = trim((string)($_POST['description'] ?? ''));
  $price_unit   = trim((string)($_POST['price_unit'] ?? 'hour'));

  // Lat/Lng required
  $lat_raw = trim((string)($_POST['latitude'] ?? ''));
  $lng_raw = trim((string)($_POST['longitude'] ?? ''));
  if ($lat_raw === '' || $lng_raw === '') {
    send_json(["success"=>false, "message"=>"latitude and longitude are required"], 400);
  }
  $latitude  = (float)$lat_raw;
  $longitude = (float)$lng_raw;

  if ($owner_id <= 0 || $parking_name === '' || $location === '') {
    send_json(["success"=>false, "message"=>"Missing required fields"], 400);
  }

  // Pricing (optional)
  $price_cars  = isset($_POST['price_cars'])  ? (int)$_POST['price_cars']  : 0;
  $price_vans  = isset($_POST['price_vans'])  ? (int)$_POST['price_vans']  : 0;
  $price_bikes = isset($_POST['price_bikes']) ? (int)$_POST['price_bikes'] : 0;
  $price_buses = isset($_POST['price_buses']) ? (int)$_POST['price_buses'] : 0;

  // Spaces counts
  $spaces_cars  = isset($_POST['spaces_cars'])  ? (int)$_POST['spaces_cars']  : 0;
  $spaces_vans  = isset($_POST['spaces_vans'])  ? (int)$_POST['spaces_vans']  : 0;
  $spaces_bikes = isset($_POST['spaces_bikes']) ? (int)$_POST['spaces_bikes'] : 0;
  $spaces_buses = isset($_POST['spaces_buses']) ? (int)$_POST['spaces_buses'] : 0;

  // -------- Prepare upload folder --------
  $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $parking_name));
  if ($slug === '') { $slug = 'space-'.time(); }

  $relDir = "uploads/owners/{$owner_id}/{$slug}/";       // stored in DB
  $absDir = rtrim(__DIR__, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relDir);

  if (!is_dir($absDir) && !@mkdir($absDir, 0777, true)) {
    send_json(["success"=>false, "message"=>"Failed to create upload directory"], 500);
  }

  // -------- Agreement (PDF) optional --------
  $agreement_path = null;
  if (isset($_FILES['agreement']) && is_array($_FILES['agreement']) && $_FILES['agreement']['error'] === UPLOAD_ERR_OK) {
    $ts = time();
    $agreeName = "agreement_{$owner_id}_{$slug}_{$ts}.pdf";
    $dest = $absDir . $agreeName;
    if (!@move_uploaded_file($_FILES['agreement']['tmp_name'], $dest)) {
      send_json(["success"=>false, "message"=>"Failed to save agreement"], 500);
    }
    $agreement_path = $relDir . $agreeName;
  }

  // -------- Photos: accept `photos` OR `photos[]` (single/multiple) --------
  $savedPhotos = [];

  $field = null;
  if (isset($_FILES['photos']))       { $field = $_FILES['photos']; }
  elseif (isset($_FILES['photos[]'])) { $field = $_FILES['photos[]']; }

  if ($field && isset($field['name'])) {
    $names = is_array($field['name']) ? $field['name'] : [$field['name']];
    $tmps  = is_array($field['tmp_name']) ? $field['tmp_name'] : [$field['tmp_name']];
    $errs  = is_array($field['error']) ? $field['error'] : [$field['error']];

    $allowed = ['jpg','jpeg','png','gif','webp'];

    foreach ($names as $i => $orig) {
      if (!isset($errs[$i]) || $errs[$i] !== UPLOAD_ERR_OK) { continue; }

      $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
      if ($ext === '' || !in_array($ext, $allowed, true)) {
        // best effort infer from mime if extension missing
        $mime = @mime_content_type($tmps[$i]) ?: '';
        if (strpos($mime, 'jpeg') !== false) $ext = 'jpg';
        elseif (strpos($mime, 'png') !== false) $ext = 'png';
        elseif (strpos($mime, 'gif') !== false) $ext = 'gif';
        elseif (strpos($mime, 'webp') !== false) $ext = 'webp';
        else continue;
      }

      $filename = sprintf("photo_%d_%s.%s", $i+1, bin2hex(random_bytes(4)), $ext);
      $dest = $absDir . $filename;
      if (@move_uploaded_file($tmps[$i], $dest)) {
        $savedPhotos[] = $relDir . $filename; // relative path we can expose later
      }
    }
  }

  // -------- Insert DB rows --------
  $mysqli->begin_transaction();

  // Always store the folder path (even if currently empty)
  $photos_path = $relDir;

  $sql = "INSERT INTO parking_space
          (owner_id, parking_name, location, availability, status, description, agreement_path, photos_path, latitude, longitude)
          VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?)";
  $stmt = $mysqli->prepare($sql);
  if (!$stmt) {
    $mysqli->rollback();
    send_json(["success"=>false, "message"=>"prepare failed (parking_space)"], 500);
  }

  // i s s s s s s d d  (9 placeholders after the literal 'pending')
  $stmt->bind_param(
    "issssssdd",
    $owner_id,
    $parking_name,
    $location,
    $availability,
    $description,
    $agreement_path,
    $photos_path,
    $latitude,
    $longitude
  );

  if (!$stmt->execute()) {
    $stmt->close();
    $mysqli->rollback();
    send_json(["success"=>false, "message"=>"insert failed (parking_space)"], 500);
  }
  $parking_space_id = $stmt->insert_id;
  $stmt->close();

  // spaces snapshot
  if ($spaces_cars || $spaces_vans || $spaces_bikes || $spaces_buses) {
    if ($stmt = $mysqli->prepare("INSERT INTO spaces (parking_space_id, cars, vans, bikes, buses) VALUES (?, ?, ?, ?, ?)")) {
      $stmt->bind_param("iiiii", $parking_space_id, $spaces_cars, $spaces_vans, $spaces_bikes, $spaces_buses);
      $stmt->execute();
      $stmt->close();
    }
  }

  // pricing
  if ($stmt = $mysqli->prepare("INSERT INTO pricing (parking_space_id, price_unit, cars, vans, bikes, buses) VALUES (?, ?, ?, ?, ?, ?)")) {
    $stmt->bind_param("isiiii", $parking_space_id, $price_unit, $price_cars, $price_vans, $price_bikes, $price_buses);
    $stmt->execute();
    $stmt->close();
  }

  $mysqli->commit();

  // -------- Build absolute URLs for newly-saved photos (response sugar) --------
  $isHttps = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
    (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
  );
  $scheme  = $isHttps ? 'https' : 'http';
  $host    = $_SERVER['HTTP_HOST'] ?? 'localhost';
  $webBase = rtrim($scheme . '://' . $host, '/') . '/Parkmate';

  $photos_urls = array_map(function($rel) use ($webBase) {
    $rel = ltrim($rel, '/');
    return $webBase . '/' . $rel;
  }, $savedPhotos);

  send_json([
    "success"          => true,
    "parking_space_id" => $parking_space_id,
    "agreement_path"   => $agreement_path,
    "photos_path"      => $photos_path,
    "photos"           => $photos_urls,
    "latitude"         => $latitude,
    "longitude"        => $longitude
  ]);

} catch (Throwable $e) {
  if ($mysqli) { @mysqli_rollback($mysqli); }
  send_json(["success"=>false, "message"=>"Server error"], 500);
}
